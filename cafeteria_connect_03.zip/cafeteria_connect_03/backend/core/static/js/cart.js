function getCSRFToken() {
    // return document.querySelector('[name=csrfmiddlewaretoken]').value;
    var csrfInput = document.querySelector('[name=csrfmiddlewaretoken]');
    if (csrfInput) {
        return csrfInput.value;
    }
    if (!csrfInput){
      const name = 'csrftoken';
      const cookies = document.cookie.split(';');
      for (let cookie of cookies) {
          csrfInput = cookie.trim();
          if (csrfInput.startsWith(name + '=')) {
              csrfInput.substring(name.length + 1);
          }
      }
      return '';
    }
    return csrfInput;
}

function addToCart(productId, quantity = 1) {
    fetch('/cart/add/', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'X-CSRFToken': getCSRFToken()
        },
        body: JSON.stringify({ product_id: productId, quantity: quantity })
    })
    .then(res => res.json())
    .then(data => {
        alert(data.message);
        if (data.status === 'error') {
            if (confirm("Clear cart to add from a new shop?")) {
                clearCart(() => addToCart(productId, quantity));
            }
        }
    });
}


function clearCart(callback) {
    fetch('/cart/clear/', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'X-CSRFToken': getCSRFToken()
        }
    })
    .then(res => res.json())
    .then(data => {
        alert(data.message);
        if (callback) callback();
    });
}


// function placeOrder() {
//     fetch('/cart/place-order/', {
//         method: 'POST',
//         headers: {
//             'Content-Type': 'application/json',
//             'X-CSRFToken': getCSRFToken()
//         }
//     })
//     .then(res => res.json())
//     .then(data => {
//         alert(data.message);
//     });
// }



function placeOrder(shopId) {
    const selectedIds = [...document.querySelectorAll('.product-id')].map(el => el.value);
    const quantities = {};

    selectedIds.forEach(id => {
        quantities[id] = document.getElementById(`quantity_${id}`).value;
    });

    fetch(`/orders/place/${shopId}/`, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'X-CSRFToken': getCSRFToken()
        },
        body: JSON.stringify({
            product_ids: selectedIds,
            quantities: quantities
        })
    })
    .then(res => res.json())
    .then(data => {
        alert(data.message);
        if (data.status === 'success') {
            window.location.href = `/orders/success/${data.order_id}/`;
        }
    });
}

function updateCartCount() {
    fetch('/cart/count/')
        .then(res => res.json())
        .then(data => {
            document.getElementById("cart-count").textContent = data.count;
        });
}